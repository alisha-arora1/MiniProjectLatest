package com.capgemini.service;

public class UserServiceImpl {

}
