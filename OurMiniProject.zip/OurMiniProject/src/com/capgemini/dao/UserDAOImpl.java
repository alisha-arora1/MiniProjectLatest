package com.capgemini.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.beans.Hotel;
import com.capgemini.beans.RoomDetails;
import com.capgemini.exception.HotelException;
import com.capgemini.util.DBUtils;

public class UserDAOImpl implements UserDAO {
	
          Logger logger = Logger.getRootLogger();
          public UserDAOImpl()
          {
        	  PropertyConfigurator.configure("resources/log4j.properties");
          }
	
	
	private Connection dbConnection; 

	{
		try {
			dbConnection = DBUtils.getConnection();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/*@Override
	public String userVerification(String user_id, String password) throws HotelException {
		
		String loginQuery = "select * from Users where user_id=? and password=?";
		String role= "";
		
		try {
			PreparedStatement insertStatement = dbConnection.prepareStatement(loginQuery);
			
			
			insertStatement.setString(1, user_id);
			insertStatement.setString(2, password);
			ResultSet result = insertStatement.executeQuery();
			while(result.next())
			{
			String userid=result.getString(1);
			String pswd=result.getString(2);
			
			//if(pswd.equals(password))
			//{
				System.out.println("Valid user..");
				logger.info("Valid user..");
				 role= result.getString(3);
				 
				return role;
			}
			
				System.out.println("\n user id or password is incorrect");
			    
			
			
		} catch (SQLException e) {
			e.printStackTrace();
			logger.error(e.getMessage());
	     	throw new HotelException("Login failed...");
		}
		return null;
		
		
	
	}*/

	@Override
	public void retrieveHotelDetails() throws HotelException {
		
		String selectquery= " select * from Hotel h join RoomDetails r on h.hotel_id=r.hotel_id";
		
		try{
			PreparedStatement insertStatement = dbConnection.prepareStatement(selectquery);
            ResultSet result= insertStatement.executeQuery();
            while(result.next()){
            	
            	String hotel_id=result.getString(1);
            	String city=result.getString(2);
            	String hotel_name=result.getString(3);
            	String address=result.getString(4);
            	String description=result.getString(5);
            	Double avg_rate_per_night=result.getDouble(6);
            	String phone_no1=result.getString(7);
            	String phone_no2=result.getString(8);
                String rating=result.getString(9);
                String email=result.getString(10);
                String fax=result.getString(11);
                String hotel_id1=result.getString(12);
            	String room_id=result.getString(13);
            	String room_no=result.getString(14);
            	String room_type=result.getString(15);
            	Double per_night_rate=result.getDouble(16);
            	String availability=result.getString(17);
            	
                
                 Hotel h=new Hotel();
                 RoomDetails r=new RoomDetails();
                 
                 h.setHotel_id(hotel_id);
                 h.setCity(city);
                 h.setHotel_name(hotel_name);
                 h.setAddress(address);
                 h.setDescription(description);
                 h.setAvg_rate_per_night(avg_rate_per_night);
                 h.setPhone_no1(phone_no1);
                 h.setPhone_no2(phone_no2);
                 h.setRating(rating);
                 h.setEmail(email);
                 h.setFax(fax);
          
                 r.setHotel_id(hotel_id1);
                 r.setRoom_id(room_id);
                 r.setRoom_no(room_no);
                 r.setRoom_type(room_type);
                 r.setPer_night_rate(per_night_rate);
                 r.setAvailability(availability);
                 
            
                 System.out.println("\n Hotel Id: "+h.getHotel_id());
                 System.out.println("\n City:"+h.getCity());
                 System.out.println("\n Hotel Name:"+ h.getHotel_name());
                 System.out.println("\n Address:"+ h.getAddress());
                 System.out.println("\n Description:"+ h.getDescription());
                 System.out.println("\n Average rate per night:"+h.getAvg_rate_per_night());
                 System.out.println("\n Phone no1:"+ h.getPhone_no1());
                 System.out.println("\n Phone no 2:"+ h.getPhone_no2());
                 System.out.println("\n Rating:"+ h.getRating());
                 System.out.println("\n Email:"+h.getEmail());
                 System.out.println("\n Fax:"+h.getFax());
                 System.out.println("\n Hotel Id:"+ r.getHotel_id());
                 System.out.println("\n Room Id:"+r.getRoom_id());
                 System.out.println("\n Room no:"+r.getRoom_no());
                 System.out.println("\n Room Type:"+r.getRoom_type());
                 System.out.println("\n Per night rate:"+ r.getPer_night_rate());
                 System.out.println("\n Availability:"+r.getAvailability());
                 
         
                 }
            }
            catch (SQLException e) {
    			e.printStackTrace();
    			logger.error(e.getMessage());
    			throw new HotelException("Failed to retrieve details");
    			
    		}
		
	}
	
	@Override
	public boolean bookRooms(String room_id,String user_id,String booking_from,String booking_to,int no_of_adults,int no_of_children,double amount) throws HotelException
	{
		
	    String insertquery= " insert into BookingDetails values(booking_id_seq.nextval(),?,?,?,?,?,?,?) ";
		
		try{
	        	PreparedStatement insertStatement= dbConnection.prepareStatement(insertquery);
	        	
	        	insertStatement.setString(1, room_id);
				insertStatement.setString(2, user_id);
				insertStatement.setString(3, booking_from);
				insertStatement.setString(4, booking_to);
				insertStatement.setInt(5, no_of_adults);
				insertStatement.setInt(6, no_of_children);
				insertStatement.setDouble(7, amount);
				
				int rows = insertStatement.executeUpdate();
				
				if((rows > 0))
				{
					System.out.println("Booking Confirmed succesfully...");
					logger.info("Added a row in db now...");
					return true;
				}
					
					
				else 
					return false;
				
			} catch (SQLException e) {
				e.printStackTrace();
				logger.error(e.getMessage());
				throw new HotelException("Failed to Book...");
			}
	        	
	        	
	}        	
	        	
	public double calculateAmount(String room_id,int no_of_days) throws HotelException{
		
		 String selectquery= " select per_night_rate from RoomDetails where room_id=?";
		 double amount;
		 try {
				PreparedStatement ps = dbConnection.prepareStatement(selectquery);
				ps.setString(1, room_id);
				ResultSet res = ps.executeQuery();
				
				if(no_of_days<0){
					throw new HotelException("Invalid input");
				}
				else
				{
					 amount=0.0;
					while(res.next()){
						amount=res.getDouble("per_night_rate");
						
					}
					amount=amount*no_of_days;
					ps.setDouble(7, amount);
					ps.executeUpdate();
				}
				
			}catch (SQLException e) {
		              e.printStackTrace();
		              logger.error(e.getMessage());
		              throw new HotelException("Failed to get Amount...");
	}
		
		 return amount;
	
	}
	
}

